StartupEvents.registry("block", event => {

    // Compressed Blocks
    event.create('plasma_resistant_casing')
    .displayName("§6Plasma Resistant Casing")
    .soundType('metal')
    .resistance(5)
    .hardness(5)
    .tagBlock("mineable/pickaxe")
    .tagBlock("forge:mineable/wrench")
    .requiresTool(true)
    .defaultCutout();

    function MetalCasings(namespace, displayName) {
        event.create(namespace)
        .displayName(displayName)
        .tagBlock("mineable/pickaxe")
        .tagBlock("forge:mineable/wrench")
        .soundType('metal')
        .hardness(5)
        .requiresTool(true)
        .resistance(5)
        .defaultCutout();
    }

    MetalCasings("plasma_resistant", "§6Plasma Resistant Casing");
    // MetalCasings("unstable_logic", "§6Unstable Logic Capable Casings");
    // MetalCasings("stable_logic", "§6Stable Logic Capable Casings");
    // MetalCasings("advanced_logic", "§6Advanced Logic Capable Casings");
    // MetalCasings("perfected_logic", "§6Perfected Logic Capable Casings");
    // MetalCasings("phoenix_enriched_neutronium_casing", "§fGravi-Stable Casing");
    // MetalCasings("phoenix_enriched_tritanium_casing", "§6Extremely Heat-Stable Casing");
    // MetalCasings("heat_dissipating_coil", "§6Heat-Dissipating §cCoils");
    // MetalCasings("supercooled_reactor_core", "§bSupercooled §6Reactor Core");

});
